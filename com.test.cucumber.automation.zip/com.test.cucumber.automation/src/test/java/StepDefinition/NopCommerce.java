package StepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Base.BaseClass;
import NopCommercePages.CustomerPage;
import NopCommercePages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class NopCommerce extends BaseClass{
	WebDriver driver;
	LoginPage lp;
	CustomerPage cp;
	
	@Given("Open application")
	public void open_application() {
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
		driver.get("https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F");
		lp= new LoginPage(driver);

	}

	@When("Enter userName {string} and Enter password {string}")
	public void enter_userName_and_Enter_password(String username, String password) {
		lp.enterUserName(username);
		lp.enterPassword(password);
	
	}

	@When("Click Login")
	public void click_Login() throws Exception {
		lp.clickLoginButton();
	 
	}

	@Given("Navigate to customer page")
	public void navigate_to_customer_page() throws InterruptedException {
		cp= new CustomerPage(driver);
		cp.goToCustomerPage();
	
	}

	@When("Click on add new customer")
	public void click_on_add_new_customer() {
			cp.clickAddNew();
	 
	}

	@When("Fill the customer details {string},{string} and click on submit")
	public void fill_the_customer_details_and_click_on_submit(String firstname, String lastname) {
	  cp.addCustomer(firstname,lastname);
	}

	@Then("Verify success message")
	public void verify_success_message() {
		cp.verifyConfirmationMsg();
		
	
	}

}
