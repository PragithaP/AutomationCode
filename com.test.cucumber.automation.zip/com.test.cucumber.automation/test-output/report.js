$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:Features/NopCommerce.feature");
formatter.feature({
  "name": "Login",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Add new customer",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "Navigate to customer page",
  "keyword": "Given "
});
formatter.step({
  "name": "Click on add new customer",
  "keyword": "When "
});
formatter.step({
  "name": "Fill the customer details \"\u003cFirstname\u003e\",\"\u003cLastname\u003e\" and click on submit",
  "keyword": "And "
});
formatter.step({
  "name": "Verify success message",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "Firstname",
        "Lastname"
      ]
    },
    {
      "cells": [
        "John",
        "Peter"
      ]
    },
    {
      "cells": [
        "James",
        "Thomas"
      ]
    }
  ]
});
formatter.background({
  "name": "",
  "description": "Login to the application",
  "keyword": "Background"
});
formatter.step({
  "name": "Open application",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.open_application()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter userName \"admin@yourstore.com\" and Enter password \"admin\"",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.enter_userName_and_Enter_password(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click Login",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.click_Login()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Add new customer",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "Navigate to customer page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.navigate_to_customer_page()"
});
formatter.result({
  "error_message": "org.openqa.selenium.ElementClickInterceptedException: element click intercepted: Element is not clickable at point (-125, 201)\n  (Session info: chrome\u003d96.0.4664.110)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-Q2RM1HI\u0027, ip: \u002710.1.10.106\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_301\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 96.0.4664.110, chrome: {chromedriverVersion: 96.0.4664.45 (76e4c1bb2ab46..., userDataDir: C:\\Users\\admin\\AppData\\Loca...}, goog:chromeOptions: {debuggerAddress: localhost:57029}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true}\nSession ID: 65918aed7898f8f420782e29d7e4a168\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:51)\r\n\tat com.sun.proxy.$Proxy19.click(Unknown Source)\r\n\tat NopCommercePages.CustomerPage.goToCustomerPage(CustomerPage.java:86)\r\n\tat StepDefinition.NopCommerce.navigate_to_customer_page(NopCommerce.java:44)\r\n\tat ✽.Navigate to customer page(file:///C:/Users/admin/eclipse-workspace/com.test.cucumber.automation/./Features/NopCommerce.feature:15)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "Click on add new customer",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.click_on_add_new_customer()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Fill the customer details \"John\",\"Peter\" and click on submit",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.fill_the_customer_details_and_click_on_submit(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Verify success message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.verify_success_message()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "name": "",
  "description": "Login to the application",
  "keyword": "Background"
});
formatter.step({
  "name": "Open application",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.open_application()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter userName \"admin@yourstore.com\" and Enter password \"admin\"",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.enter_userName_and_Enter_password(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click Login",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.click_Login()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Add new customer",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "Navigate to customer page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.navigate_to_customer_page()"
});
formatter.result({
  "error_message": "org.openqa.selenium.ElementClickInterceptedException: element click intercepted: Element is not clickable at point (-125, 201)\n  (Session info: chrome\u003d96.0.4664.110)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-Q2RM1HI\u0027, ip: \u002710.1.10.106\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_301\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 96.0.4664.110, chrome: {chromedriverVersion: 96.0.4664.45 (76e4c1bb2ab46..., userDataDir: C:\\Users\\admin\\AppData\\Loca...}, goog:chromeOptions: {debuggerAddress: localhost:57052}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true}\nSession ID: 778c8ad0f26c222fba18b200c37dcd88\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:51)\r\n\tat com.sun.proxy.$Proxy19.click(Unknown Source)\r\n\tat NopCommercePages.CustomerPage.goToCustomerPage(CustomerPage.java:86)\r\n\tat StepDefinition.NopCommerce.navigate_to_customer_page(NopCommerce.java:44)\r\n\tat ✽.Navigate to customer page(file:///C:/Users/admin/eclipse-workspace/com.test.cucumber.automation/./Features/NopCommerce.feature:15)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "Click on add new customer",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.click_on_add_new_customer()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Fill the customer details \"James\",\"Thomas\" and click on submit",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.fill_the_customer_details_and_click_on_submit(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Verify success message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.NopCommerce.verify_success_message()"
});
formatter.result({
  "status": "skipped"
});
});