package Calculator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class calculator {
	
	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver= new ChromeDriver();
		
		
		driver.get("https://juliemr.github.io/protractor-demo/");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input[ng-model=\"first\"]")).sendKeys("1122");
		
				driver.findElement(By.cssSelector("input[ng-model=\"second\"]")).sendKeys("3133");
				driver.findElement(By.cssSelector("#gobutton")).click();
				Thread.sleep(2000);
				String result=driver.findElement(By.cssSelector(".ng-binding")).getText();
				Thread.sleep(4000);
				Assert.assertEquals(result, "4255");
				System.out.println("Pass");
				
				
				driver.close();
				
				
		
	}

}

