package TestCase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class OrangeHRMTest {
	WebDriver driver;
	LoginPage lp;
	
	
	@BeforeTest
	public void launch() {
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/");
		lp = new LoginPage(driver);
		
	}
	
	@Test(priority=0)
	public void alogin() throws InterruptedException {
		
		 lp.login("admin","admin123");
		 
	}
//	@Test (priority=1)
//	public void forgotPwd() {
//		lp.clickForgotPwd();
//	}
	
	@Test (priority=1)
	public void logout() throws InterruptedException {
		lp.logout();
	}
	
	
	
	

}
