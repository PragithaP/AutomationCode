package Pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPage extends BaseClass{

	
	@FindBy(id="txtUsername")
	WebElement userName;
	
	@FindBy(id="txtPassword")
	WebElement password;
	
	@FindBy(id="btnLogin")
	WebElement btnLogin;
	
	@FindBy(linkText="Welcome Paul")
	WebElement welcomelink;
	@FindBy(linkText="Logout")
	WebElement Logout;
	
	
	
	@FindBy(linkText="Forgot your password?")
	WebElement forgotpwd;
	  public LoginPage(WebDriver rdriver) {

	        this.driver = rdriver;
	        PageFactory.initElements(rdriver, this);

	    }
	 
	
	

	public void login(String username, String pwd) throws InterruptedException {
		
		userName.sendKeys("admin");
	     password.sendKeys("admin123");
		btnLogin.click();
	}
	
	
	
	public void clickForgotPwd() {
		forgotpwd.click();
	}
	
	public void logout() throws InterruptedException {
		Thread.sleep(2000);
		welcomelink.click();
		Thread.sleep(2000);
		Logout.click();
		
	}
	
	
}
