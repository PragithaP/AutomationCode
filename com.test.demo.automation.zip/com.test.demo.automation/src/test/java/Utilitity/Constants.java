package Utilitity;

public class Constants {
	
		public static final String URL = "https://demoqa.com/automation-practice-form";
		public static final String Path_TestData = ".\\testData\\";
		public static final String File_TestData = "RegisterStudent.xls";
		public static final String File_TestData2 = "RegistrationData.xlsx";
		

}
