package Base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Base {
	
	 Properties prop;
//	public static void main(String[] args) throws IOException {
//		Base b = new Base();
//		
//		FileInputStream file= new FileInputStream("C:\\Users\\admin\\eclipse-workspace\\com.Test.Project\\Objects.properties");
//		prop= new Properties();
//		prop.load(file);
//		System.out.println(b.getUrl());
//	}
	
	public String getUrl() {
		return prop.getProperty("URL");
	}
	
	public Base () throws IOException {
		FileInputStream file= new FileInputStream("C:\\Users\\admin\\eclipse-workspace\\com.Test.Project\\Objects.properties");
		prop= new Properties();
		prop.load(file);
	}
	
	public String getUsername() {
		return prop.getProperty("username");
	}
    public String gePassword() {
    	return prop.getProperty("password");
	}

}
