package Base;

import org.testng.annotations.Test;

public class test extends BaseClass{
	
	
	@Test
	public void test() {
		driver.getTitle();
	}

}
