package NopCommerceTest;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import Base.BaseClass;
import Base.BaseClass2;
import NopCommercePages.CustomerPage;
import NopCommercePages.LoginPage;

public class NopCommerceTest2 extends BaseClass2{
    LoginPage lp;
    CustomerPage cp;
    
  
    
    @BeforeTest
    public void launch() {
        lp = new LoginPage(driver);
        driver.get("https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F");
        cp = new CustomerPage(driver);
        
        
    }
	
	@Test(priority=1)
	public void login() throws Exception {
		 logger = extent.createTest("Login");
	        lp.enterUserName("admin@yourstore.com");
	        lp.enterPassword("admin");
	        lp.clickLoginButton();
	}
	@Test(priority=2)
	public void addCustomer() throws InterruptedException, IOException {
		 logger = extent.createTest("add customer");
		cp.goToCustomerPage();
		cp.verifyCustomerPage();
		cp.addNewCustomer();
		
	}
//	  @AfterMethod
//	    public void getResult(ITestResult result) throws IOException {
//	        if (result.getStatus() == ITestResult.FAILURE) {
//	            // MarkupHelper is used to display the output in different colors
//	            logger.log(Status.FAIL,
//	                    MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
//	            logger.log(Status.FAIL,
//	                    MarkupHelper.createLabel(result.getThrowable() + " - Test Case Failed", ExtentColor.RED));
//	          //  String screenshotPath = getScreenShot(driver, result.getName());
//	            // To add it in the extent report
//	        //    logger.fail("Test Case Failed Snapshot is below " + logger.addScreenCaptureFromPath(screenshotPath));
//	        } 
//	        else if (result.getStatus() == ITestResult.SKIP) {
//	            logger.log(Status.SKIP,
//	                    MarkupHelper.createLabel(result.getName() + " - Test Case Skipped", ExtentColor.ORANGE));
//	        } 
//	        else if (result.getStatus() == ITestResult.SUCCESS) {
//	            logger.log(Status.PASS,
//	                    MarkupHelper.createLabel(result.getName() + " Test Case PASSED", ExtentColor.GREEN));
//	        }
//	        
//	    }
	
	
}

