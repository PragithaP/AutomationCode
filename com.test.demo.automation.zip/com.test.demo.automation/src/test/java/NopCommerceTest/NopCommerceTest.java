package NopCommerceTest;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import Base.BaseClass;
import NopCommercePages.CustomerPage;
import NopCommercePages.LoginPage;

public class NopCommerceTest extends BaseClass{
    LoginPage lp;
    CustomerPage cp;
    
   
    
    @BeforeTest
    public void launch() {
        lp = new LoginPage(driver);
        driver.get("https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F");
        cp = new CustomerPage(driver);
        
    }
	
	@Test(priority=1)
	public void login() throws Exception {
		 logger = extent.createTest("To verify Login feature");
	        lp.enterUserName("admin@yourstore.com");
	        lp.enterPassword("admin");
	        lp.clickLoginButton();
	        
	}
	@Test(priority=2)
	public void addCustomer() throws InterruptedException, IOException {
		 logger = extent.createTest("Add customer");
		cp.goToCustomerPage();
		cp.verifyCustomerPage();
		cp.addNewCustomer();
		
		
		
		
	}
	
	 
}

